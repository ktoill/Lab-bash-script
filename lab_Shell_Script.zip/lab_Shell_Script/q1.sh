mkdir test
mkdir test/mytest
cp *.txt test/mytest
cp edit2.txt test
mv test/mytest/edit1.txt test/mytest/edit1.doc
ls -Ra

